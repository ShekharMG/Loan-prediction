import pandas as pd

from sklearn.linear_model import LinearRegression
from sklearn import metrics
import numpy as np


dataset = pd.read_csv("loan.csv").dropna() # Replace the "Loan.csv" with your dataset file name or path
print(dataset.corr())
x=dataset[' cibil_score'].values.reshape(-1, 1) # change 'Cibil' to choosen x column name in your dataset
y=dataset[' loan_amount']                        # change 'income amount' to choosen y column name in your dataset

results = {}
models = {}
print("\n--------training models for rain ----------")

try:
    clf = LinearRegression()
    clf.fit(x, y)
    y_pred = clf.predict(x)
    score = np.sqrt(metrics.mean_squared_error(y, y_pred))
    print("%s : %f " % ("Linear Regression", score * 0.00001))
    results["Linear Regression"] = score
    models["Linear Regression"] = clf
except Exception as e:
    pass
winner = min(results, key=results.get)
result=round(models[winner].predict([[700]])[0],2) # replace x with value which we need to predict predict([[x]])[0],2)

print("Predicted output : " + str(result))