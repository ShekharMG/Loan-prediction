import pandas as pd
  
df = pd.read_csv("loan.csv").dropna()

correlation_matrix = df.corr()
print(correlation_matrix)
correlation_matrix.to_csv('correlationsloan.csv')