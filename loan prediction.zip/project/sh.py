import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

def kernel(point, xmat, k):
    weights = np.eye(len(xmat))
    weights[np.diag_indices_from(weights)] = np.exp(np.sum((point - xmat)**2, axis=1) / (-2.0 * k**2))
    return weights

def localweight(point, xmat, ymat, k):
    wei = kernel(point, xmat, k)
    w = np.linalg.inv(xmat.T @ (wei @ xmat)) @ (xmat.T @ (wei @ ymat.T))
    return w

def localWeightRegression(xmat, ymat, k):
    ypred = xmat @ np.apply_along_axis(lambda x: localweight(x, xmat, ymat, k), 1, xmat)
    return ypred

data = pd.read_csv('10.csv')
bill, tip = np.array(data.total_bill), np.array(data.tip)
X = np.hstack((np.ones((len(bill), 1)), np.mat(bill).T))
ypred = localWeightRegression(X, np.mat(tip).T, 10)
sortIndex = X[:, 1].argsort(0)
xsort = X[sortIndex][:, 0]

fig, ax = plt.subplots()
ax.scatter(bill, tip, color='green')
ax.plot(xsort[:, 1], ypred[sortIndex], color='red', linewidth=5)
plt.xlabel('TotalBill')
plt.ylabel('Tip')
plt.show()
